package com.cjc.webapp.crud.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudOprationApplication
{

	public static void main(String[] args) 
	{
		
		System.out.println("SpringBoot Crud Opration");
		
		SpringApplication.run(SpringBootCrudOprationApplication.class, args);
	}

}
