package com.cjc.webapp.crud.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudOprationApplicationTests {

	@Test
	void contextLoads() {
	}

}
